<!DOCTYPE html>
<html>
<head>
    <title>Flutter.com</title>
</head>
<body>
    <h1><?php echo e($maildetails['Subject']); ?></h1>
    <p><?php echo e($maildetails['body']); ?></p>

        <p> Welcome,Our App</p>
    </body>
</html><?php /**PATH C:\xampp\htdocs\MOE\resources\views/mail.blade.php ENDPATH**/ ?>